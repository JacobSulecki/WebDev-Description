document.getElementById("nav").addEventListener("mouseover", function() {
    document.getElementById("nav").style.backgroundColor = "rgb(201, 201, 201)";
});

document.getElementById("nav").addEventListener("mouseout", function() {
    document.getElementById("nav").style.backgroundColor = "transparent";
});